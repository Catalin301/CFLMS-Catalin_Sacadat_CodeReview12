<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
  <meta name="description" content="<?php bloginfo('description'); ?>"> 
	<title><?php bloginfo('name'); ?></title>
	<!--<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
  <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/bootstrap.css">-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

   <?php wp_head(); ?> 
</head>
<body>

  <?php get_header(); ?>

<hr>



<div class="row">
  <div class="col-md-4">
    <div class="single-blog">
      <p class="blog-meta">By Admin <span>August 3,2020</span></p>
        <img src="https://i.pinimg.com/originals/a5/9b/4a/a59b4ad81841d50272e78b8d029f28c3.jpg" alt="">
        <h2 class="text-center"><a href="#">City</a></h2>
          <p class="blog-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
            <p><a href="" class="read-more-btn">Read more</a>
              <span>
                <i class=" fa fa-thumbs-up"></i>7 People like,<i class="fa fa-comment-o">3...</i>
              </span>
            </p>
    </div>
  </div>

  <div class="col-md-4">
    <div class="single-blog">
      <p class="blog-meta">By Admin <span>August 3,2020</span></p>
        <img src="https://alliswall.com/file/4048/1920x1200/16:9/amazing-nature-background-.jpg" alt="">
        <h2 class="text-center"><a href="#">Country house</a></h2>
          <p class="blog-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
            <p><a href="" class="read-more-btn">Read more</a>
              <span>
                <i class=" fa fa-thumbs-up"></i>7 People like,<i class="fa fa-comment-o">3...</i>
              </span>
            </p>
    </div>
  </div>

  <div class="col-md-4">
    <div class="single-blog">
      <p class="blog-meta">By Admin <span>August 3,2020</span></p>
        <img src="https://wallpapertag.com/wallpaper/full/9/a/1/125478-gorgerous-background-nature-1920x1080-for-meizu.jpg" alt="">
        <h2 class="text-center"><a href="#">Amazing View</a></h2>
          <p class="blog-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
            <p><a href="" class="read-more-btn">Read more</a>
              <span>
                <i class=" fa fa-thumbs-up"></i>7 People like,<i class="fa fa-comment-o">3...</i>
              </span>
            </p>
    </div>
  </div>
</div>


<div class="row">
  <div class="col-md-4">
    <div class="single-blog">
      <p class="blog-meta">By Admin <span>August 3,2020</span></p>
        <img src="https://cdn.sortra.com/wp-content/uploads/2014/11/sam-elkins08.jpg" alt="">
        <h2 class="text-center"><a href="#">Awesome street</a></h2>
          <p class="blog-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
            <p><a href="" class="read-more-btn">Read more</a>
              <span>
                <i class=" fa fa-thumbs-up"></i>7 People like,<i class="fa fa-comment-o">3...</i>
              </span>
            </p>
    </div>
  </div>

  <div class="col-md-4">
    <div class="single-blog">
      <p class="blog-meta">By Admin <span>August 3,2020</span></p>
        <img src="https://thewallpaper.co/wp-content/uploads/2016/01/organic-photos-amazing-nature-wallpapers-green-fresh-iphone-desktop-images-hd-landscape-wallpapers-sky-samsung-nature-wallpapers-1920x1026.jpg" alt="">
        <h2 class="text-center"><a href="#">Mountain lake </a></h2>
          <p class="blog-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
            <p><a href="" class="read-more-btn">Read more</a>
              <span>
                  <i class=" fa fa-thumbs-up"></i>7 People like,<i class="fa fa-comment-o">3...</i>
              </span>
            </p>
    </div>
  </div>

  <div class="col-md-4">
    <div class="single-blog">
      <p class="blog-meta">By Admin <span>August 3,2020</span></p>
        <img src="https://cdn.sympathink.com/wp-content/uploads/night-photography-tips-ideas.jpg" alt="">
        <h2 class="text-center"><a href="#">Sleep under the stars</a></h2>
          <p class="blog-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
            <p><a href="" class="read-more-btn">Read more</a>
              <span>
                <i class=" fa fa-thumbs-up"></i>7 People like,<i class="fa fa-comment-o">3...</i>
              </span>
            </p>
    </div>
  </div>

  <div class="col-md-4">
    <div class="single-blog">
      <p class="blog-meta">By Admin <span>August 3,2020</span></p>
        <img src="https://www.wallpaperup.com/uploads/wallpapers/2016/11/05/1031782/3b76e80e28f8417004b536d51b1c25e8.jpg" alt="">
        <h2 class="text-center"><a href="#">Mountain Lake</a></h2>
          <p class="blog-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
            <p><a href="" class="read-more-btn">Read more</a>
              <span>
                <i class=" fa fa-thumbs-up"></i>7 People like,<i class="fa fa-comment-o">3...</i>
              </span>
            </p>
    </div>
  </div>

  <div class="col-md-4">
    <div class="single-blog">
      <p class="blog-meta">By Admin <span>August 3,2020</span></p>
        <img src="https://c4.wallpaperflare.com/wallpaper/791/992/873/nature-cool-wallpaper-preview.jpg" alt="">
        <h2 class="text-center"><a href="#">Lake Huron</a></h2>
          <p class="blog-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
            <p><a href="" class="read-more-btn">Read more</a>
              <span>
                <i class=" fa fa-thumbs-up"></i>7 People like,<i class="fa fa-comment-o">3...</i>
              </span>
            </p>
    </div>
  </div>

  <div class="col-md-4">
    <div class="single-blog">
      <p class="blog-meta">By Admin <span>August 3,2020</span></p>
        <img src="https://i.pinimg.com/originals/ae/32/d3/ae32d3f4bd82c2d500f939bf57d3f939.jpg" alt="">
        <h2 class="text-center"><a href="#">Lake Mountain</a></h2>
          <p class="blog-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
            <p><a href="" class="read-more-btn">Read more</a>
              <span>
                <i class=" fa fa-thumbs-up"></i>7 People like,<i class="fa fa-comment-o">3...</i>
              </span>
            </p>
    </div>
  </div>
</div>

<hr>

<!--<div class="secondCards">
  <div class="container-fluid contenedor text-center ">
      <h1 class="text-center"></h1>
    <div class=" container text-center">

      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 container_foto"> 

         <article class="text-left">
            <h2>Rom <br>Italy</h2>
            <h4>Amazing city!</h4>
         </article>
         <img class="imgS"src="https://reisenexclusiv.com/wp-content/uploads/2018/05/Rom-Foto-prochasson-frederic-e1526042036748.jpg" alt="">
      </div>

      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 container_foto">
       
         <article class="text-left">
            <h2>Barcelona<br>Spain</h2>
            <h4>Amazing city!</h4>
         </article>
         <img class="imgS" src="https://media-cdn.holidaycheck.com/w_1280,h_720,c_fill,q_80/ugc/images/99397a99-a780-3bc0-8704-1345530de71a" alt="">
      </div>

      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 container_foto">
      
         <article class="text-left">
            <h2>Dublin<br>Ireland</h2>
            <h4>Amazing city!</h4>
         </article>
         <img class="imgS" src="https://live.staticflickr.com/8282/29028858596_e8a7055a69_b.jpg" alt="">
      </div>

          <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 container_foto">
      
         <article class="text-left">
            <h2>Vienna<br>Austria</h2>
            <h4>Amazing city!</h4>
         </article>
         <img class="imgS" src="https://www.worldtravelguide.net/wp-content/uploads/2017/03/shu-Austria-Vienna-StCharles-420505375-1440x823.jpg" alt="">
      </div>

    </div>
  </div>
</div>-->

<div class="container">
  <h1>Hello!</h1>
    <div class="content">
      <?php if(have_posts()) : ?>
      <?php while(have_posts()) : the_post(); ?>
        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <p><?php the_time('F j, Y g:i a'); ?></p>

            <div class="description"><?php the_excerpt(); ?></div>

              <?php endwhile; ?>
                <?php else : ?>
                  <?php_('No Posts found'); ?>
              <?php endif; ?> 
    </div>
</div>
<div class="cal">


<hr>
<?php
    if(is_active_sidebar('sidebar')):
    dynamic_sidebar('sidebar');
    endif;  
?>
</div>


  <?php get_footer(); ?>
</body>
</html>