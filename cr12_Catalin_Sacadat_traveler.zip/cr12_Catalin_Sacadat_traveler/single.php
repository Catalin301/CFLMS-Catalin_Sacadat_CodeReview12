<?php get_header(); ?>

<div class="cal">
<?php
    if(is_active_sidebar('sidebar')):
    dynamic_sidebar('sidebar');
    endif;  
?>
</div>

<div class="container">
  <h1>Hello from a single post!</h1>
    <div class="content">
      <?php if(have_posts()) : ?>
      <?php while(have_posts()) : the_post(); ?>
        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <p><?php the_time('F j, Y g:i a'); ?></p>
          <p><?php the_author(); ?></p>
            <div class="description"><?php the_content(); ?></div>

              <?php endwhile; ?>
                <?php else : ?>
                  <?php_('No Posts found'); ?>
              <?php endif; ?> 
    </div>
</div>

<?php get_footer(); ?>
